#!/usr/bin/env python3
"""
md_to_mp3.py - Convert Markdown files to MP3 using Microsoft Edge TTS

Usage:
    python3 md_to_mp3.py <input.md> [output.mp3] [--voice zh-CN-YunxiNeural] [--rate 0.9] [--bgm music.mp3] [--bgm-volume 0.15]

Batch usage:
    python3 md_to_mp3.py --batch <directory> [--output-dir <dir>] [--voice zh-CN-YunxiNeural] [--rate 0.9] [--bgm music.mp3]

Requires:
    pip install edge-tts
"""

import argparse
import asyncio
import os
import re
import subprocess
import sys
import time
from pathlib import Path


def strip_markdown(text: str) -> str:
    """Remove Markdown formatting and chapter metadata, preserving clean body text for TTS."""
    # 1. Remove YAML frontmatter (--- delimited, must start at line 1)
    text = re.sub(r'^---\s*\n.*?\n---\s*\n', '', text, flags=re.DOTALL)

    # 2. Remove chapter summary block (**【本章概要】** ... next ---)
    text = re.sub(r'\*\*【本章概要】\*\*[\s\S]*?(?=\n---\n)', '', text)
    text = re.sub(r'\*\*【本章概要】\*\*[\s\S]*?(?=---)', '', text)

    # 3. Remove ending footer: **【第X章完 · 约XXX字】** + stats + footnotes
    text = re.sub(r'\*\*【第[一二三四五六七八九十\d]+章完\s*[·・]\s*约?\d+字】\*\*', '', text)
    text = re.sub(r'^\*字数[：:].*$', '', text, flags=re.MULTILINE)
    text = re.sub(r'^\*主角[：:].*$', '', text, flags=re.MULTILINE)
    text = re.sub(r'^\*保存路径[：:].*$', '', text, flags=re.MULTILINE)

    # 4. Remove footnote definitions: [^1]: text
    text = re.sub(r'^\[\^\d+\]:\s*.*$', '', text, flags=re.MULTILINE)
    # Remove footnote references in body: [^1]
    text = re.sub(r'\[\^\d+\]', '', text)

    # 5. Remove custom highlight/strikethrough: ==text== and ~~text~~
    # Use [^=\n] / [^~\n] to prevent matching across newlines (greedy bug)
    text = re.sub(r'==([^=\n]+)==', r'\1', text)
    text = re.sub(r'~~([^~\n]+)~~', r'\1', text)
    # Remove any remaining unpaired == or ~~ markers (broken edit marks)
    text = re.sub(r'(?<!=)==(?!=)', '', text)
    text = re.sub(r'(?<!~)~~(?!~)', '', text)

    # 6. Remove code blocks (``` ... ```) and inline code (`...`)
    text = re.sub(r'```[\s\S]*?```', '', text)
    text = re.sub(r'`[^`]*`', '', text)

    # 7. Remove HTML tags
    text = re.sub(r'<[^>]+>', '', text)

    # 8. Remove images: ![alt](url) -> alt
    text = re.sub(r'!\[([^\]]*)\]\([^)]*\)', r'\1', text)

    # 9. Remove links: [text](url) -> text
    text = re.sub(r'\[([^\]]*)\]\([^)]*\)', r'\1', text)

    # 10. Remove headings (# ## ### etc.) - keep the text
    text = re.sub(r'^#{1,6}\s+', '', text, flags=re.MULTILINE)

    # 11. Remove horizontal rules (---, ***, ___)
    text = re.sub(r'^[-*_]{3,}\s*$', '', text, flags=re.MULTILINE)

    # 12. Remove bold/italic markers (** **, * *, __ __, _ _)
    text = re.sub(r'\*{2}([^*]+)\*{2}', r'\1', text)
    text = re.sub(r'\*([^*]+)\*', r'\1', text)
    text = re.sub(r'_{2}([^_]+)_{2}', r'\1', text)
    text = re.sub(r'_([^_]+)_', r'\1', text)

    # 13. Remove list markers (-, *, +, 1., 2.)
    text = re.sub(r'^\s*[-*+]\s+', '', text, flags=re.MULTILINE)
    text = re.sub(r'^\s*\d+\.\s+', '', text, flags=re.MULTILINE)

    # 14. Remove blockquote markers (>)
    text = re.sub(r'^\s*>\s*', '', text, flags=re.MULTILINE)

    # 15. Remove table markers (| and -|-)
    text = re.sub(r'^\|?\s*:?-+:?\s*\|?\s*$', '', text, flags=re.MULTILINE)
    text = re.sub(r'\|\s*', ' ', text)

    # 16. Clean up excessive whitespace
    text = re.sub(r'\n{3,}', '\n\n', text)
    text = re.sub(r'  +', ' ', text)
    text = text.strip()

    return text


def chunk_text(text: str, max_chars: int = 5000) -> list[str]:
    """
    Split text into chunks that respect sentence boundaries.
    Microsoft Edge TTS has a request size limit (~5000 chars is safe).
    """
    chunks = []
    # Split by sentences (Chinese/English punctuation)
    sentences = re.split(r'(?<=[。！？!?\n])', text)

    current_chunk = ""
    for sentence in sentences:
        if not sentence.strip():
            continue
        if len(current_chunk) + len(sentence) <= max_chars:
            current_chunk += sentence
        else:
            if current_chunk:
                chunks.append(current_chunk.strip())
            # If a single sentence is too long, force-split it
            if len(sentence) > max_chars:
                for i in range(0, len(sentence), max_chars):
                    chunks.append(sentence[i:i + max_chars].strip())
                current_chunk = ""
            else:
                current_chunk = sentence

    if current_chunk:
        chunks.append(current_chunk.strip())

    return chunks


async def text_to_mp3(text: str, output_path: str, voice: str = "zh-CN-YunxiNeural",
                     rate: float = 0.9, max_retries: int = 3) -> bool:
    """Convert text to MP3 using edge-tts with automatic retry on transient errors."""
    try:
        import edge_tts
    except ImportError:
        print("ERROR: edge-tts not installed. Run: pip install edge-tts")
        return False

    rate_pct = int((rate - 1.0) * 100)
    rate_str = f"{rate_pct:+d}%"

    last_error = None
    tts_timeout = 300  # 单个 TTS 请求最长等待秒数，防止网络挂起导致进程卡死
    for attempt in range(max_retries):
        try:
            communicate = edge_tts.Communicate(text, voice=voice, rate=rate_str)
            await asyncio.wait_for(communicate.save(output_path), timeout=tts_timeout)
            return True
        except asyncio.TimeoutError:
            last_error = f"TTS timeout after {tts_timeout}s"
            # 清理可能生成的不完整文件，避免被误判为已完成
            try:
                if os.path.exists(output_path):
                    os.remove(output_path)
            except OSError:
                pass
            if attempt < max_retries - 1:
                delay = 2 ** attempt
                print(f"  TTS timeout, retry {attempt + 1}/{max_retries - 1} after {delay}s...")
                await asyncio.sleep(delay)
        except Exception as e:
            last_error = str(e)
            if attempt < max_retries - 1:
                delay = 2 ** attempt  # 1s, 2s, 4s backoff
                if "No audio" in last_error or "rate" in last_error.lower():
                    print(f"  Retry {attempt + 1}/{max_retries - 1} after {delay}s ({last_error})...")
                    await asyncio.sleep(delay)
                else:
                    # Non-recoverable error, don't retry
                    break

    print(f"ERROR during TTS conversion: {last_error}")
    return False


def get_audio_duration(file_path: str) -> float:
    """Get the duration of an audio file in seconds using ffprobe."""
    try:
        import json
        cmd = [
            'ffprobe', '-v', 'quiet',
            '-show_entries', 'format=duration',
            '-of', 'json',
            file_path
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        data = json.loads(result.stdout)
        return float(data['format']['duration'])
    except (FileNotFoundError, subprocess.CalledProcessError, json.JSONDecodeError, KeyError, ValueError):
        return 0.0


async def add_bgm(mp3_path: str, bgm_path: str, bgm_volume: float) -> None:
    """Loop BGM to cover the full MP3 duration and mix at specified volume using ffmpeg.
    
    The BGM is looped (via -stream_loop) to fill the entire TTS audio duration,
    regardless of the original BGM length.
    Writes to a temporary file first, then replaces the original in-place.
    
    Args:
        mp3_path: Path to the input MP3 file
        bgm_path: Path to the BGM MP3 file
        bgm_volume: Volume level for BGM (0.0 to 1.0), default 0.10
    """
    mp3_path_obj = Path(mp3_path)
    tmp_path = mp3_path_obj.parent / f".tmp_bgm_mix_{mp3_path_obj.name}.mp3"
    try:
        mp3_dur = get_audio_duration(mp3_path)
        if mp3_dur <= 0:
            raise ValueError(f"Cannot determine MP3 duration from {mp3_path}")
        
        cmd = [
            'ffmpeg', '-y',
            '-stream_loop', '-1',
            '-i', bgm_path,
            '-i', mp3_path,
            '-filter_complex',
            f'[0:a]volume={bgm_volume}[bgm];[1:a][bgm]amix=inputs=2:duration=first[out]',
            '-map', '[out]',
            '-codec:a', 'libmp3lame',
            '-t', str(mp3_dur),
            str(tmp_path)
        ]
        subprocess.run(cmd, capture_output=True, check=True)
        
        # Replace original with mixed file in-place
        tmp_path.rename(mp3_path_obj)
    except (FileNotFoundError, subprocess.CalledProcessError, subprocess.TimeoutExpired, ValueError) as e:
        print(f"  WARNING: BGM overlay failed: {e}")
        tmp_path.unlink(missing_ok=True)


async def convert_file(input_path: str, output_path: str = None,
                      voice: str = "zh-CN-YunxiNeural", rate: float = 0.9,
                      bgm_path: str = None, bgm_volume: float = 0.10,
                      verbose: bool = False) -> bool:
    """Convert a single MD file to MP3."""
    input_path = Path(input_path)

    if not input_path.exists():
        print(f"ERROR: File not found: {input_path}")
        return False

    if not output_path:
        output_path = input_path.with_suffix('.mp3')
    else:
        output_path = Path(output_path)

    if verbose:
        print(f"Reading: {input_path}")

    with open(input_path, 'r', encoding='utf-8') as f:
        md_content = f.read()

    clean_text = strip_markdown(md_content)

    if not clean_text.strip():
        print(f"WARNING: No clean text found in {input_path.name}, skipping.")
        return False

    if verbose:
        print(f"Clean text length: {len(clean_text)} chars")
        print(f"Voice: {voice}, Rate: {rate}")
        print(f"Output: {output_path}")
        if bgm_path:
            print(f"BGM: {bgm_path} (volume: {bgm_volume})")

    # Chunk long text
    chunks = chunk_text(clean_text)
    if verbose:
        print(f"Split into {len(chunks)} chunk(s)")

    if len(chunks) == 1:
        success = await text_to_mp3(chunks[0], str(output_path), voice, rate)
        if success:
            # Add BGM if provided
            if bgm_path and Path(bgm_path).exists():
                if verbose:
                    print(f"  Adding BGM: {bgm_path} (volume={bgm_volume})")
                await add_bgm(str(output_path), bgm_path, bgm_volume)
            if verbose:
                size_kb = output_path.stat().st_size / 1024
                print(f"Done: {output_path.name} ({size_kb:.1f} KB)")
        return success
    else:
        # Multiple chunks: convert each and concatenate
        import tempfile
        chunk_files = []
        for i, chunk in enumerate(chunks):
            tmp_file = output_path.parent / f".tmp_chunk_{i}_{output_path.stem}.mp3"
            if verbose:
                print(f"  Converting chunk {i+1}/{len(chunks)} ({len(chunk)} chars)...")
            success = await text_to_mp3(chunk, str(tmp_file), voice, rate)
            if success:
                chunk_files.append(tmp_file)
            else:
                print(f"ERROR: Failed on chunk {i+1}")
                # Clean up temp files
                for cf in chunk_files:
                    cf.unlink(missing_ok=True)
                return False

        # Concatenate MP3 files
        if verbose:
            print(f"Concatenating {len(chunk_files)} chunks...")
        concatenate_mp3(chunk_files, output_path)

        # Clean up temp files and add BGM if provided
        for cf in chunk_files:
            cf.unlink(missing_ok=True)

        if success:
            if bgm_path and Path(bgm_path).exists():
                if verbose:
                    print(f"  Adding BGM: {bgm_path} (volume={bgm_volume})")
                await add_bgm(str(output_path), bgm_path, bgm_volume)

        if verbose:
            if success and output_path.exists():
                size_kb = output_path.stat().st_size / 1024
                print(f"Done: {output_path.name} ({size_kb:.1f} KB)")
        return True


def concatenate_mp3(files: list[Path], output: Path):
    """Concatenate multiple MP3 files into one using ffmpeg or simple binary concat."""
    try:
        import subprocess
        # Try using ffmpeg for proper concatenation
        list_file = output.parent / f".tmp_list_{output.stem}.txt"
        with open(list_file, 'w', encoding='utf-8') as f:
            for mp3_file in files:
                f.write(f"file '{mp3_file.absolute()}'\n")
        cmd = [
            'ffmpeg', '-f', 'concat', '-safe', '0', '-i', str(list_file),
            '-c', 'copy', '-y', str(output)
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)
        list_file.unlink(missing_ok=True)
        if result.returncode == 0:
            return
        # Fall through to binary concat if ffmpeg fails
    except (ImportError, FileNotFoundError):
        pass

    # Fallback: simple binary concatenation
    with open(output, 'wb') as outfile:
        for mp3_file in files:
            with open(mp3_file, 'rb') as infile:
                outfile.write(infile.read())


async def batch_convert(input_dir: str, voice: str = "zh-CN-YunxiNeural",
                       rate: float = 0.9, output_dir: str = None,
                       bgm_path: str = None, bgm_volume: float = 0.10,
                       verbose: bool = False) -> dict:
    """Batch convert all .md files in a directory."""
    input_dir = Path(input_dir)
    md_files = sorted(input_dir.glob('*.md'))

    if not md_files:
        print(f"No .md files found in {input_dir}")
        return {"success": 0, "failed": 0, "skipped": 0}

    out_dir = Path(output_dir) if output_dir else input_dir
    out_dir.mkdir(parents=True, exist_ok=True)

    print(f"Found {len(md_files)} .md file(s) in {input_dir}")
    if output_dir:
        print(f"Output directory: {out_dir}")
    results = {"success": 0, "failed": 0, "skipped": 0}

    for i, md_file in enumerate(md_files, 1):
        print(f"\n[{i}/{len(md_files)}] {md_file.name}")
        output_file = out_dir / f"{md_file.stem}.mp3"
        if output_file.exists():
            size_kb = output_file.stat().st_size / 1024
            if size_kb > 1:  # > 1KB means valid, skip
                print(f"  Skipped (MP3 already exists, {size_kb:.0f} KB)")
                results["skipped"] += 1
                continue
            else:
                # Broken file, remove and re-convert
                output_file.unlink()
                print(f"  Removed broken 0-byte file, re-converting...")

        success = await convert_file(str(md_file), str(output_file), voice, rate, bgm_path, bgm_volume, verbose)
        if success:
            results["success"] += 1
        else:
            results["failed"] += 1

    print(f"\n{'='*50}")
    print(f"Batch complete: {results['success']} success, "
          f"{results['failed']} failed, {results['skipped']} skipped")
    return results


async def main():
    parser = argparse.ArgumentParser(description="Convert Markdown files to MP3 using Microsoft Edge TTS")
    parser.add_argument("input", nargs="?", help="Input .md file path")
    parser.add_argument("output", nargs="?", help="Output .mp3 file path (optional)")
    parser.add_argument("--batch", help="Batch convert all .md files in directory")
    parser.add_argument("--output-dir", help="Output directory for batch mode (default: same as input)")
    parser.add_argument("--voice", default="zh-CN-YunxiNeural",
                        help="TTS voice (default: zh-CN-YunxiNeural)")
    parser.add_argument("--rate", type=float, default=0.9,
                        help="Speech rate/speed (default: 0.9)")
    parser.add_argument("--bgm", help="Background music file path")
    parser.add_argument("--bgm-volume", type=float, default=0.10,
                        help="BGM volume level 0.0-1.0 (default: 0.10)")
    parser.add_argument("-v", "--verbose", action="store_true", help="Verbose output")
    args = parser.parse_args()

    if args.batch:
        await batch_convert(args.batch, args.voice, args.rate, args.output_dir, args.bgm, args.bgm_volume, args.verbose)
    elif args.input:
        success = await convert_file(args.input, args.output, args.voice, args.rate, args.bgm, args.bgm_volume, args.verbose)
        sys.exit(0 if success else 1)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
