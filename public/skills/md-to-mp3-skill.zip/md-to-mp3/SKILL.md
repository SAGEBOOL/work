---
name: md-to-mp3
description: 将 Markdown 文件批量转换为 MP3 音频。使用微软 Edge 免费 TTS，默认男声 zh-CN-YunxiNeural，语速 0.9x。自动去除标题、加粗、代码块、列表、引用等 Markdown 标记，保留纯净正文，合成语音自然流畅。适用于小说章节、文章、文档的语音化。触发词："转MP3"、"md转音频"、"批量转语音"、"章节转MP3"、"story-video预处理"。
agent_created: true
---

# md-to-mp3

## 概述

此技能使用微软 Edge 免费 TTS 服务，将 Markdown 文件批量转换为高质量 MP3 音频。自动清理 Markdown 格式标记，输出适合语音合成的纯净文本。

**核心特性：**
- 批量转换：支持单文件或整个目录的 `.md` 文件，支持 `--output-dir` 自定义输出目录
- 格式清理：自动去除 Markdown 标记（标题、加粗、代码块、列表、引用、链接、图片等）
- **章节元数据清理**：自动过滤 YAML 头、章节概要、尾页统计、脚注，仅保留正文
- 长文本分块：自动将超过限制的文本分块处理，再合并为完整 MP3
- 语音参数：默认男声 `zh-CN-YunxiNeural`，语速 `0.9x`（可调整）
- **自动重试**：对 transient 错误（如 "No audio"）自动重试最多 3 次（指数退避）
- **BGM 配乐**：使用 `--bgm` 参数指定背景音文件，默认音量 10%（`--bgm-volume 0.10`），ffmpeg 混音合成，音量更低以避免遮挡人声
- 零成本：使用微软 Edge 免费 TTS API，无需 API Key

## 依赖安装

使用前需安装 `edge-tts` Python 包（只需一次）：

```bash
pip install edge-tts
```

可选依赖（用于多分块 MP3 合并）：
```bash
# macOS (already installed)
# Ubuntu/Debian
sudo apt install ffmpeg
```

## 使用方式

### 单文件转换

```bash
python3 scripts/md_to_mp3.py knowledge-base-jiejie/stories/chap1.md
# 输出：knowledge-base-jiejie/stories/chap1.mp3

python3 scripts/md_to_mp3.py input.md output.mp3 --voice zh-CN-YunxiNeural --rate 0.9 --bgm bgm.mp3
```

### 批量转换

```bash
# 输出到源目录（同名 .mp3）
python3 scripts/md_to_mp3.py --batch knowledge-base-jiejie/stories/

# 指定输出目录（源目录只读时使用）
python3 scripts/md_to_mp3.py --batch knowledge-base-jiejie/stories/ --output-dir /path/to/output/

# 已存在的有效 MP3（>1KB）自动跳过，0字节文件自动重转
```

### 参数说明

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `input` | (必填) | 输入 `.md` 文件路径 |
| `output` | 同名 `.mp3` | 输出 MP3 路径 |
| `--batch` | - | 批量转换目录（传入目录路径） |
| `--output-dir` | 同输入目录 | 批量模式输出目录（默认与源目录相同） |
| `--voice` | `zh-CN-YunxiNeural` | TTS 音色（男声云希） |
| `--rate` | `0.9` | 语速倍率（0.5~2.0） |
| `--bgm` | - | 背景音 MP3/WAV 文件路径 |
| `--bgm-volume` | `0.10` | BGM 音量（0.0~1.0），默认 10%，不遮挡人声 |
| `-v` / `--verbose` | `False` | 显示详细转换进度 |

### 常用音色参考

| 音色代码 | 说明 |
|----------|------|
| `zh-CN-YunxiNeural` | 男声·云希（默认，推荐小说朗读） |
| `zh-CN-XiaoxiaoNeural` | 女声·晓晓（温和） |
| `zh-CN-YunyangNeural` | 男声·云扬（新闻播报风格） |
| `zh-CN-XiaoyiNeural` | 女声·晓伊（活泼） |
| `zh-CN-YunyeNeural` | 男声·云野（温和） |

## 工作流程

当用户请求将 MD 文件转为 MP3 时，按以下步骤操作：

### 1. 确认输入来源

- 如果用户指定了文件路径或目录，直接使用
- 如果用户说"我的小说章节"，默认使用 `knowledge-base-jiejie/stories/` 目录
- 支持 glob 模式匹配

### 2. 检查依赖

```bash
python3 -c "import edge_tts; print('edge-tts OK')" 2>/dev/null || {
  echo "安装 edge-tts..."
  pip install edge-tts
}
```

### 3. 执行转换

- **单文件**：直接调用 `md_to_mp3.py`，传入文件路径
- **批量**：使用 `--batch` 参数，传入目录路径
- 转换完成后，报告生成的 MP3 文件路径和文件大小

### 4. 输出结果

以表格形式向用户展示转换结果：

```
| 原文件 | 输出 MP3 | 大小 | 状态 |
|--------|-----------|------|------|
| chap1.md | chap1.mp3 | 2.3 MB | ✅ 成功 |
```

## Markdown 清理规则

脚本会自动去除以下 Markdown 和章节元数据格式（保留纯净正文文本）：

- **YAML 头**：`---...---` 前置元数据 → 完全去除
- **章节概要**：`**【本章概要】**` 块 → 完全去除
- **章末统计**：`**【第X章完 · 约XXX字】**` + 字数/主角/路径统计 → 完全去除
- **标题**：`# ## ###` 等，去除标记保留文字
- **加粗/斜体**：`**text**` ` *text*` `__text__` `_text_` → `text`
- **高亮/删除线**：`==text==` `~~text~~` → `text`（含孤立标记清理）
- **代码块**：` ```code``` ` 和 `` `inline code` `` → 去除
- **列表**：`- * + 1.` 等列表标记 → 去除
- **引用**：`> quote` → 去除 `>` 保留文字
- **链接**：`[text](url)` → 保留 `text`
- **图片**：`![alt](url)` → 保留 `alt`（如有）
- **脚注**：`[^1]: text` 和 `[^1]` 引用 → 完全去除
- **表格**：`| col |` 标记 → 去除标记保留内容
- **水平线**：`--- ***` → 去除

## 长文本处理

微软 Edge TTS 单次请求有字符数限制（约 5000 字符）。脚本会自动：

1. **按句分割**：以 `。！？!?\n` 为界分割文本
2. **分块转换**：每块 ≤ 5000 字符，分别调用 TTS
3. **合并输出**：使用 ffmpeg 或二进制拼接合并所有分块 MP3
4. **清理临时文件**：合并后自动删除分块临时文件

## 注意事项

- **输出质量**：`zh-CN-YunxiNeural` 对中文小说朗读效果最佳，语音自然流畅
- **语速调整**：`--rate 0.9` 比默认稍慢，适合小说朗读；技术文档可用 `1.0` 或 `1.1`
- **文件覆盖**：已存在的 `.mp3` 在批量模式下会自动跳过；单独转换时会覆盖
- **BGM 配乐**：`--bgm bgm.mp3` 指定背景音文件，`--bgm-volume 0.10` 设置 BGM 音量（10%），比语音显著降低，完全不会遮挡人声。
- **英文混排**：Edge TTS 对中英混排支持良好，无需特殊处理
- **离线使用**：需要网络连接（调用微软免费 TTS 服务）

## 典型使用场景

**场景 1：小说章节转语音**
```
用户："把九界归尘第17章转成MP3"
→ 执行：python3 scripts/md_to_mp3.py knowledge-base-jiejie/stories/he-yi-chapter-17.md --voice zh-CN-YunxiNeural --rate 0.9 -v
```

**场景 2：带 BGM 的章节转语音**
```
用户："带背景音乐转章节，BGM音量10%"
→ 执行：python3 scripts/md_to_mp3.py he-yi-chapter-17.md --bgm bgms/ambient.mp3 --bgm-volume 0.10 -v
```

**场景 2：批量转换所有章节**
```
用户："把 stories 目录下所有md批量转MP3"
→ 执行：python3 scripts/md_to_mp3.py --batch knowledge-base-jiejie/stories/ -v
```

**场景 3：story-video 预处理**
```
用户："生成视频"（触发 story-video 技能）
→ 先检查对应章节是否有 MP3，若无则调用本技能生成，再传入 story-video
```
