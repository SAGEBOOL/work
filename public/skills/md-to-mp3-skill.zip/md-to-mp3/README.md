# md-to-mp3 技能插件

将 Markdown 文件批量转换为 MP3 音频。使用微软 Edge 免费 TTS，默认男声 `zh-CN-YunxiNeural`，语速 0.9x。自动清理 Markdown 标记，可选叠加 BGM 背景音（循环覆盖整段时长，默认音量 10%）。

## 目录结构

```
md-to-mp3/
├── SKILL.md                 # 技能元数据与使用说明（WorkBuddy 自动加载）
├── scripts/
│   └── md_to_mp3.py         # 核心转换脚本
├── test-files/
│   └── test-sample.md       # 示例 Markdown
├── requirements.txt         # Python 依赖
├── install.sh               # 一键安装脚本
└── README.md                # 本文件
```

## 安装

### 方式一：一键安装（推荐）

```bash
bash install.sh
```

脚本会把技能复制到 `~/.workbuddy/skills/md-to-mp3/`，然后安装依赖：

```bash
pip install -r ~/.workbuddy/skills/md-to-mp3/requirements.txt
```

### 方式二：手动安装

```bash
# 1. 复制技能目录
cp -R md-to-mp3 ~/.workbuddy/skills/

# 2. 安装 Python 依赖
pip install edge-tts

# 3. 确认系统已安装 ffmpeg（BGM 混音与多分块合并需要）
#    macOS:  brew install ffmpeg
#    Ubuntu: sudo apt install ffmpeg
```

## 依赖

| 依赖 | 类型 | 说明 |
|------|------|------|
| `edge-tts` | Python 包 | 微软 Edge 免费 TTS，无需 API Key |
| `ffmpeg` / `ffprobe` | 系统工具 | BGM 混音、长文本分块合并；macOS 通常已自带 |

## 使用

### 单文件

```bash
python3 ~/.workbuddy/skills/md-to-mp3/scripts/md_to_mp3.py input.md
# 输出：input.mp3

python3 ~/.workbuddy/skills/md-to-mp3/scripts/md_to_mp3.py input.md output.mp3 \
  --voice zh-CN-YunxiNeural --rate 0.9 \
  --bgm /path/to/bgm.mp3 --bgm-volume 0.10
```

### 批量

```bash
# 输出到源目录（同名 .mp3）
python3 ~/.workbuddy/skills/md-to-mp3/scripts/md_to_mp3.py --batch /path/to/stories/

# 指定输出目录
python3 ~/.workbuddy/skills/md-to-mp3/scripts/md_to_mp3.py --batch /path/to/stories/ \
  --output-dir /path/to/output/
```

### 常用参数

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `input` | 必填 | 输入 `.md` 文件（或 `--batch` 时传目录） |
| `output` | 同名 `.mp3` | 输出路径 |
| `--batch` | - | 批量转换目录 |
| `--output-dir` | 同输入目录 | 批量输出目录 |
| `--voice` | `zh-CN-YunxiNeural` | TTS 音色 |
| `--rate` | `0.9` | 语速倍率（0.5~2.0） |
| `--bgm` | - | 背景音文件路径 |
| `--bgm-volume` | `0.10` | BGM 音量（0.0~1.0） |
| `-v` | `False` | 详细进度 |

## 说明

- 已存在的有效 MP3（>1KB）在批量模式下自动跳过，0 字节文件自动重转。
- BGM 通过 `ffmpeg -stream_loop -1` 循环播放，截取至与 TTS 语音等长，不遮挡人声。
- 需要网络连接（调用微软免费 TTS 服务）。
