#!/usr/bin/env bash
# md-to-mp3 技能安装脚本
# 用法：bash install.sh
# 将本技能安装到当前用户的 WorkBuddy 技能目录

set -e

SKILL_NAME="md-to-mp3"
SRC_DIR="$(cd "$(dirname "$0")/${SKILL_NAME}" && pwd)"
DEST="$HOME/.workbuddy/skills/${SKILL_NAME}"

if [ ! -f "$SRC_DIR/SKILL.md" ]; then
  echo "❌ 未找到 SKILL.md，请确认在技能包根目录运行此脚本"
  exit 1
fi

mkdir -p "$DEST"
cp -R "$SRC_DIR/." "$DEST/"

echo "✅ 已安装到: $DEST"
echo ""
echo "下一步：安装 Python 依赖（只需一次）"
echo "  pip install -r $DEST/requirements.txt"
echo ""
echo "验证："
echo "  python3 $DEST/scripts/md_to_mp3.py --help"
echo ""
echo "注意：BGM 混音与多分块合并依赖系统 ffmpeg，请确认已安装（macOS: brew install ffmpeg；Ubuntu: sudo apt install ffmpeg）"
